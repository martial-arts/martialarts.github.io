<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "html";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection




?>
